import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import {AntDesign, Entypo, EvilIcons, Feather, FontAwesome, FontAwesome5, Fontisto, Foundation, Ionicons, MaterialCommunityIcons, MaterialIcons, Octicons, SimpleLineIcons, Zocial} from '@expo/vector-icons'; 

export default function App() {
  return (
    <View style={styles.container}>

      {/*1ª Familia*/}
      <Text>AntDesign</Text>
      <View>
      <AntDesign name="home" size={24} color="gray" />
      <AntDesign name="bars" size={24} color="gray" />
      <AntDesign name="clockcircle" size={24} color="black" />
      <AntDesign name="infocirlceo" size={24} color="red" />
      <AntDesign name="checkcircleo" size={24} color="green" />
      </View>
      
      {/*2ª Familia*/}
      <Text>Entypo</Text>
      <View>
      <Entypo name="500px" size={24} color="purple" />
      <Entypo name="calculator" size={24} color="gray" />
      <Entypo name="chat" size={24} color="black" />
      <Entypo name="block" size={24} color="red" />
      <Entypo name="adjust" size={24} color="orange" />
      </View>

      {/*3ª Familia*/}
      <Text>EvilIcons</Text>
      <View>
      <EvilIcons name="chart" size={24} color="black" />
      <EvilIcons name="camera" size={24} color="gray" />
      <EvilIcons name="sc-google-plus" size={24} color="blue" />
      <EvilIcons name="heart" size={24} color="red" />
      <EvilIcons name="paperclip" size={24} color="gray" />
      </View>

      {/*4ª Familia*/}
      <Text>Feather</Text>
      <View>
      <Feather name="cast" size={24} color="black" />
      <Feather name="cloud-lightning" size={24} color="blue" />
      <Feather name="folder-plus" size={24} color="brown" />
      <Feather name="bluetooth" size={24} color="purple" />
      <Feather name="check-circle" size={24} color="green" />
      </View>

      {/*5ª Familia*/}
      <Text>FontAwesome</Text>
      <View>
      <FontAwesome name="leaf" size={24} color="green" />
      <FontAwesome name="plane" size={24} color="blue" />
      <FontAwesome name="thumbs-o-down" size={24} color="red" />
      <FontAwesome name="tags" size={24} color="pink" />
      <FontAwesome name="book" size={24} color="brown" />
      </View>

      {/*6ª Familia*/}
      <Text>FontAwesome5</Text>
      <View>
      <FontAwesome5 name="book-dead" size={24} color="brown" />
      <FontAwesome5 name="broom" size={24} color="brown" />
      <FontAwesome5 name="cannabis" size={24} color="green" />
      <FontAwesome5 name="angry" size={24} color="red" />
      <FontAwesome5 name="bahai" size={24} color="orange" />
      </View>

      {/*7ª Familia*/}
      <Text>Fontisto</Text>
      <View>
      <Fontisto name="dockers" size={24} color="blue" />
      <Fontisto name="gitlab" size={24} color="silver" />
      <Fontisto name="line" size={24} color="lightblue" />
      <Fontisto name="jsfiddle" size={24} color="darkblue" />
      <Fontisto name="reddit" size={24} color="purple" />
      </View>

      {/*8ª Familia*/}
      <Text>Foundation</Text>
      <View>
      <Foundation name="plus" size={24} color="lightred" />
      <Foundation name="shopping-bag" size={24} color="brown" />
      <Foundation name="skull" size={24} color="darkred" />
      <Foundation name="social-android" size={24} color="silver" />
      <Foundation name="social-facebook" size={24} color="lightblue" />
      </View>

      {/*9ª Familia*/}
      <Text>Ionicons</Text>
      <View>
      <Ionicons name="car-sport-sharp" size={24} color="darkblue" />
      <Ionicons name="cellular" size={24} color="silver" />
      </View>

      {/*10ª Familia*/}
      <Text>MaterialCommunityIcons</Text>
      <View>
      <MaterialCommunityIcons name="folder-home" size={35} color="black" />
      </View>

      {/*11ª Familia*/}
      <Text>MaterialIcons</Text>
      <View>
      <MaterialIcons name="cell-wifi" size={45} color="pink" />
      </View>

      {/*12ª Familia*/}
      <Text>Octicons</Text>
      <View>
      <AntDesign name="home" size={35} color="black" />
      </View>

      {/*13ª Familia*/}
      <Text>SimpleLineIcons</Text>
      <View>
      <MaterialCommunityIcons name="folder-home" size={35} color="black" />
      </View>
      
      {/*14ª Familia*/}
      <Text>Zocial</Text>
      <View>
      <MaterialIcons name="cell-wifi" size={45} color="pink" />
      </View>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  familiaicones:{
    backgroundColor: '#ccc',
    borderRadius: 5,
    width: '90%',
    marginBottom: 20,
    padding: 15,
  },
  lista_icones:{
    flexDirection: "row",
    marginTop: 20,
  },
  familia_titulo:{
    fontSize: 30,
    borderStyle: 'solid',
    borderColor: '#222',
    borderBottomwidth: 2
  },
  espaco_icones:{
    margin: 5
  }
});
